package edu.eci.arsw.blacklistvalidator;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import edu.eci.arsw.spamkeywordsdatasource.HostBlacklistsDataSourceFacade;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Getter
public class BlackListSearchThread  extends Thread{
    private final int start;
    private final int end;
    private final String ipaddress;
    private final AtomicInteger occurrencesCount;

    private final HostBlacklistsDataSourceFacade facade = 
        HostBlacklistsDataSourceFacade.getInstance();

    private int checkedCount = 0;
    private final List<Integer> occurrences = new ArrayList<>();
    private static final int BLACK_LIST_ALARM_COUNT = 5;
    
    @Override
    public void run(){
        for (int i = start; i < end; i++) {
            if(occurrencesCount.get()>=BLACK_LIST_ALARM_COUNT){
                break;
            }
            checkedCount++;
            if(facade.isInBlackListServer(i, ipaddress)){
                occurrences.add(i);
                occurrencesCount.incrementAndGet();
            }
        }
    }    
}
